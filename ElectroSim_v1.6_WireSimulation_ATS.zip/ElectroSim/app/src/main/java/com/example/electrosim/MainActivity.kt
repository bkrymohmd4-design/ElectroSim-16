package com.example.electrosim

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** ElectroSim v1.6 - Industrial training simulator foundation.
 *  - IEC-style component cards and terminal numbering
 *  - Real wire graph for control-path simulation
 *  - DOL starter logic with START/STOP, seal-in, overload and phase monitor
 *  - ATS automatic/manual source selection with break-before-make interlock
 */

data class Part(val name: String, val terminals: List<String>, val type: String)
data class SimEdge(val a: String, val b: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { ElectroSimApp() } }
    }
}

@Composable
fun ElectroSimApp() {
    var simOn by remember { mutableStateOf(false) }
    var startPressed by remember { mutableStateOf(false) }
    var stopPressed by remember { mutableStateOf(false) }
    var overloadTrip by remember { mutableStateOf(false) }
    var mcbTrip by remember { mutableStateOf(false) }
    var fuseBlown by remember { mutableStateOf(false) }
    var phaseL1 by remember { mutableStateOf(true) }
    var phaseL2 by remember { mutableStateOf(true) }
    var phaseL3 by remember { mutableStateOf(true) }
    var phaseReverse by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<String?>(null) }
    var wires by remember { mutableStateOf(listOf<SimEdge>()) }
    var atsAuto by remember { mutableStateOf(true) }
    var source1Ok by remember { mutableStateOf(true) }
    var source2Ok by remember { mutableStateOf(true) }
    var atsSource by remember { mutableStateOf(1) }

    val parts = remember {
        listOf(
            Part("QF1", listOf("L1", "L2", "L3", "T1", "T2", "T3"), "mcb3p"),
            Part("KM1", listOf("A1", "A2", "L1", "L2", "L3", "T1", "T2", "T3", "13", "14", "21", "22"), "contactor"),
            Part("FR1", listOf("T1", "T2", "T3", "95", "96", "97", "98"), "overload"),
            Part("M1", listOf("U1", "V1", "W1"), "motor"),
            Part("S0", listOf("11", "12"), "ncbutton"),
            Part("S1", listOf("13", "14"), "nobutton"),
            Part("H1", listOf("A1", "A2"), "lamp"),
            Part("PM1", listOf("L1", "L2", "L3", "11", "12", "14"), "phasemonitor")
        )
    }

    fun id(i: Int, t: String) = "$i:$t"
    fun qf(t: String) = id(0, t)
    fun km(t: String) = id(1, t)
    fun fr(t: String) = id(2, t)
    fun s0(t: String) = id(4, t)
    fun s1(t: String) = id(5, t)

    fun addWire(a: String, b: String) {
        if (a == b) { selected = null; return }
        if (wires.any { (it.a == a && it.b == b) || (it.a == b && it.b == a) }) { selected = null; return }
        wires = wires + SimEdge(a, b)
        selected = null
    }

    fun reachable(start: String, target: String, kmHolding: Boolean): Boolean {
        val edges = mutableListOf<SimEdge>().apply { addAll(wires) }
        if (!mcbTrip) {
            edges += SimEdge(qf("L1"), qf("T1")); edges += SimEdge(qf("L2"), qf("T2")); edges += SimEdge(qf("L3"), qf("T3"))
        }
        if (!stopPressed) edges += SimEdge(s0("11"), s0("12"))
        if (startPressed) edges += SimEdge(s1("13"), s1("14"))
        if (kmHolding) edges += SimEdge(km("13"), km("14"))
        if (!overloadTrip) edges += SimEdge(fr("95"), fr("96"))
        val seen = mutableSetOf(start)
        val queue = ArrayDeque<String>(); queue.add(start)
        while (queue.isNotEmpty()) {
            val n = queue.removeFirst()
            if (n == target) return true
            for (e in edges) {
                if (e.a == n && seen.add(e.b)) queue.add(e.b)
                if (e.b == n && seen.add(e.a)) queue.add(e.a)
            }
        }
        return false
    }

    val healthy3p = phaseL1 && phaseL2 && phaseL3 && !phaseReverse
    val pathA1 = simOn && healthy3p && !overloadTrip && !mcbTrip && reachable(qf("L1"), km("A1"), false)
    val pathA2 = simOn && healthy3p && !overloadTrip && !mcbTrip && reachable(qf("L2"), km("A2"), false)
    val holdA1 = simOn && healthy3p && !overloadTrip && !mcbTrip && reachable(qf("L1"), km("A1"), true)
    val kmOn = pathA2 && (pathA1 || holdA1)
    val motorOn = kmOn && healthy3p && !overloadTrip && !mcbTrip

    fun autoAts() {
        if (!atsAuto) return
        atsSource = when {
            source1Ok -> 1
            source2Ok -> 2
            else -> 0
        }
    }

    val atsK1 = atsSource == 1
    val atsK2 = atsSource == 2

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).background(Color(0xFFF2F4F7))) {
        Row(Modifier.fillMaxWidth().background(Color(0xFF20242A)).padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("ElectroSim 1.6", color = Color.White, style = MaterialTheme.typography.titleMedium)
                Text("Industrial IEC / DOL / ATS Simulator", color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
            }
            Button(onClick = { simOn = !simOn; if (!simOn) startPressed = false }) { Text(if (simOn) "STOP SIM" else "SIMULATE") }
        }

        Card(Modifier.fillMaxWidth().padding(8.dp)) {
            Column(Modifier.padding(10.dp)) {
                Text("LIVE NETWORK SIMULATION", style = MaterialTheme.typography.titleMedium)
                Text("3-phase: ${if (healthy3p) "HEALTHY" else "FAULT"} | QF1: ${if (mcbTrip) "TRIPPED" else "ON"} | FR1: ${if (overloadTrip) "TRIPPED" else "READY"}")
                Text("KM1 coil: ${if (kmOn) "ENERGIZED" else "DE-ENERGIZED"} | M1: ${if (motorOn) "RUNNING" else "STOPPED"}")
                Text("L1→A1: ${if (pathA1 || holdA1) "CLOSED" else "OPEN"} | A2→L2: ${if (pathA2) "CLOSED" else "OPEN"}")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(onClick = { startPressed = true }) { Text("START") }
                    Button(onClick = { startPressed = false }) { Text("RELEASE") }
                    Button(onClick = { stopPressed = !stopPressed; startPressed = false }) { Text(if (stopPressed) "RELEASE S0" else "STOP S0") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { overloadTrip = !overloadTrip }) { Text(if (overloadTrip) "RESET OL" else "TRIP OL") }
                    OutlinedButton(onClick = { mcbTrip = !mcbTrip }) { Text(if (mcbTrip) "RESET MCB" else "TRIP MCB") }
                    OutlinedButton(onClick = { wires = emptyList(); selected = null }) { Text("CLEAR WIRES") }
                }
            }
        }

        Card(Modifier.fillMaxWidth().padding(8.dp)) {
            Column(Modifier.padding(10.dp)) {
                Text("PHASE MONITOR PM1", style = MaterialTheme.typography.titleMedium)
                Text("L1 ${if (phaseL1) "OK" else "LOSS"} | L2 ${if (phaseL2) "OK" else "LOSS"} | L3 ${if (phaseL3) "OK" else "LOSS"} | SEQ ${if (phaseReverse) "REVERSE" else "OK"}")
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Button(onClick = { phaseL1 = !phaseL1 }) { Text("L1") }
                    Button(onClick = { phaseL2 = !phaseL2 }) { Text("L2") }
                    Button(onClick = { phaseL3 = !phaseL3 }) { Text("L3") }
                    Button(onClick = { phaseReverse = !phaseReverse }) { Text("REV") }
                }
            }
        }

        Card(Modifier.fillMaxWidth().padding(8.dp)) {
            Column(Modifier.padding(10.dp)) {
                Text("ATS – AUTOMATIC TRANSFER", style = MaterialTheme.typography.titleMedium)
                Text("Mode: ${if (atsAuto) "AUTO" else "MANUAL"} | Active source: ${if (atsSource == 0) "NONE" else "SOURCE $atsSource"}")
                Text("K1 SOURCE 1: ${if (atsK1) "CLOSED" else "OPEN"}   |   K2 SOURCE 2: ${if (atsK2) "CLOSED" else "OPEN"}")
                Text("INTERLOCK: ${if (!(atsK1 && atsK2)) "OK" else "FAULT"}", color = if (!(atsK1 && atsK2)) Color(0xFF16803C) else Color(0xFFC62828))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(onClick = { atsAuto = !atsAuto; autoAts() }) { Text(if (atsAuto) "MANUAL" else "AUTO") }
                    Button(onClick = { source1Ok = !source1Ok; autoAts() }) { Text("SOURCE 1 ${if (source1Ok) "OK" else "OFF"}") }
                    Button(onClick = { source2Ok = !source2Ok; autoAts() }) { Text("SOURCE 2 ${if (source2Ok) "OK" else "OFF"}") }
                }
                if (!atsAuto) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { atsSource = if (atsSource == 2) 0 else 1 }) { Text("K1 / SOURCE 1") }
                        OutlinedButton(onClick = { atsSource = if (atsSource == 1) 0 else 2 }) { Text("K2 / SOURCE 2") }
                    }
                }
            }
        }

        Card(Modifier.fillMaxWidth().padding(8.dp)) {
            Column(Modifier.padding(10.dp)) {
                Text("IEC COMPONENTS", style = MaterialTheme.typography.titleMedium)
                parts.forEachIndexed { index, p ->
                    val state = when (p.type) {
                        "contactor" -> if (kmOn) "ON" else "OFF"
                        "overload" -> if (overloadTrip) "TRIP" else "READY"
                        "motor" -> if (motorOn) "RUNNING" else "STOPPED"
                        "ncbutton" -> if (stopPressed) "OPEN" else "CLOSED"
                        "nobutton" -> if (startPressed) "CLOSED" else "OPEN"
                        "mcb3p" -> if (mcbTrip) "TRIP" else "ON"
                        "phasemonitor" -> if (healthy3p) "RELAY ON" else "RELAY OFF"
                        else -> "READY"
                    }
                    Text("${p.name} — $state", style = MaterialTheme.typography.titleSmall)
                    when (p.type) {
                        "contactor" -> {
                            Text("A1 ─── ( KM1 COIL ) ─── A2")
                            Text("13 ─── [ NO ] ─── 14 : ${if (kmOn) "CLOSED" else "OPEN"}")
                            Text("21 ─── [ NC ] ─── 22 : ${if (kmOn) "OPEN" else "CLOSED"}")
                            Text("L1 L2 L3 → T1 T2 T3")
                        }
                        "overload" -> { Text("T1 T2 T3 → U1 V1 W1"); Text("95 ─── [ NC ] ─── 96 : ${if (overloadTrip) "OPEN" else "CLOSED"}"); Text("97 ─── [ NO ] ─── 98 : ${if (overloadTrip) "CLOSED" else "OPEN"}") }
                        "mcb3p" -> { Text("L1 ──[ MCB ]── T1"); Text("L2 ──[ MCB ]── T2"); Text("L3 ──[ MCB ]── T3") }
                        "ncbutton" -> Text("11 ─── [ NC STOP ] ─── 12 : ${if (stopPressed) "OPEN" else "CLOSED"}")
                        "nobutton" -> Text("13 ─── [ NO START ] ─── 14 : ${if (startPressed) "CLOSED" else "OPEN"}")
                        "motor" -> Text("U1 / V1 / W1  →  ( M3~ )")
                        "phasemonitor" -> Text("L1 L2 L3 → PM1 → 11/12 NC, 11/14 NO")
                        "lamp" -> Text("A1 ─── ( PILOT ) ─── A2")
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp), modifier = Modifier.padding(vertical = 5.dp)) {
                        p.terminals.forEach { t ->
                            val tid = id(index, t)
                            AssistChip(onClick = { if (selected == null) selected = tid else addWire(selected!!, tid) }, label = { Text(t) })
                        }
                    }
                    HorizontalDivider()
                }
            }
        }

        Card(Modifier.fillMaxWidth().padding(8.dp)) {
            Column(Modifier.padding(10.dp)) {
                Text("WIRE NETWORK", style = MaterialTheme.typography.titleMedium)
                Text(if (selected == null) "اختر طرفاً ثم طرفاً آخر لإنشاء سلك." else "الطرف المحدد: $selected — اختر الطرف الثاني.")
                if (wires.isEmpty()) Text("لا توجد أسلاك.")
                wires.forEachIndexed { i, e -> Text("${i + 1}. ${e.a}  ─────  ${e.b}") }
                Text("المسارات الموصولة تدخل مباشرة في حساب تغذية KM1.")
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}
