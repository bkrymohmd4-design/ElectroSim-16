# ElectroSim v1.6

نسخة تعليمية لمحاكاة الدوائر الصناعية على Android.

## الجديد
- محاكاة شبكة الأسلاك فعلياً لمسار دائرة التحكم.
- DOL: START / STOP / تعشيق 13-14.
- Overload FR1: 95-96 و97-98.
- MCB trip/reset.
- Phase Monitor مع فقد فازة وعكس ترتيب الفازات.
- ATS AUTO/MANUAL مع مصدرين وInterlock.
- رموز IEC نصية وأرقام أطراف واضحة.

## البناء على AndroidIDE-R
افتح مجلد `ElectroSim` ثم نفّذ Build > Assemble Debug APK.
الملف الناتج يكون عادة داخل `app/build/outputs/apk/debug/`.
